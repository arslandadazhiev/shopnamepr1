<?php
$conn = mysqli_connect("localhost","root","root","bookshop");

$bookname=$_POST['updatename'];
$upd_id=$_POST['upd_id'];
$rub=$_POST['newrub'];
$cost=$_POST['newcost'];
$picture=$_POST['newcover'];
print_r($_POST);
if(!empty($bookname)&& !empty($upd_id) && !empty($cost)&& !empty($rub)&& !empty($picture)){
    $sql = "UPDATE `tovar` SET name='$bookname' , rub ='$rub', cost ='$cost',pic='$picture' WHERE id='$upd_id'";
$result = mysqli_query($conn,$sql);
print_r($_POST);
header("Location: index.php");
}else{
    echo "ошибка";
}
 
 

?>