<?php
$conn = mysqli_connect("localhost","root","root","bookshop");

$bookname=$_POST['bookname'];
$rubrik=$_POST['rub'];
$cost=$_POST['cost'];
$picture=$_POST['filename'];
print_r($_POST);
if(!empty($bookname)&& !empty($rubrik) && !empty($cost)&& !empty($picture)){
    $sql = "INSERT INTO `tovar`(`name`, `rub`, `cost`, `pic`) VALUES ('$bookname','$rubrik','$cost','$picture')";
$result = mysqli_query($conn,$sql);
header("Location: index.php");
 
}else{
    echo "ошибка";
}
 
 

?>