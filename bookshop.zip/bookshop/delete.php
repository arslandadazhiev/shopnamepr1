<?php
$conn = mysqli_connect("localhost","root","root","bookshop");

 
$upd_id=$_POST['delete_id'];
 
if(!empty($upd_id)){
    $sql = "DELETE FROM `tovar` WHERE id='$upd_id'";
$result = mysqli_query($conn,$sql);
print_r($_POST);
header("Location: index.php");
}else{
    echo "ошибка";
}
 
 

?>