<?php
class shop{
    private $conn = "";

    function __construct(){
        $this->conn = mysqli_connect("localhost","root","root","bookshop");

    }
   
    public function getdata(){
        $sql = "SELECT tovar.id,tovar.name,tovar.rub,tovar.cost,tovar.pic FROM tovar LEFT JOIN rub ON rub.id = tovar.id";
        $result = mysqli_query($this->conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            $array[]=$row;
        }
     
        return $array;
    }
    public function getrub(){
        $sql = "SELECT * FROM rub ";
        $result = mysqli_query($this->conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            $array[]=$row;
        }
     
        return $array;
    }
    public function select_data(){
        $sql = "SELECT id,rub FROM rub ";
        $result = mysqli_query($this->conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            $array[]=$row;
        }
     
        return $array;
    }
   
}
?>