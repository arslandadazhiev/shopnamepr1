<?php
$conn = mysqli_connect("localhost","root","root","bookshop");

 
$id=$_POST['rubid'];
$newrubname=$_POST['updaterubtext'];
 
if(!empty($id)&& !empty($newrubname)){
      $sql = "UPDATE `rub` SET rub='$newrubname' WHERE id='$id'";
$result = mysqli_query($conn,$sql);

header("Location: index.php");
}else{
    echo "ошибка";
}
 
 

?>